# 安裝所需函式庫：pip install pyzmq cbor keyboard
from coppeliasim_zmqremoteapi_client import RemoteAPIClient
import keyboard
import time

# 連接到 CoppeliaSim 伺服器
client = RemoteAPIClient('localhost', 23000)
sim = client.getObject('sim')

print('程式啟動')

# 取得滑動關節的控制句柄
slider1 = sim.getObject('/joint_lh')  # 第一隻滑動關節
if slider1 == -1:
    print("無法找到滑動關節 /joint_lh")
    exit()

slider2 = sim.getObject('/joint_rh')  # 第二隻滑動關節
if slider2 == -1:
    print("無法找到滑動關節 /joint_rh")
    exit()

slider3 = sim.getObject('/joint_push')  # 第三隻滑動關節
if slider3 == -1:
    print("無法找到滑動關節 /joint_push")
    exit()

slider4 = sim.getObject('/joint_stop')  # 第四隻滑動關節
if slider4 == -1:
    print("無法找到滑動關節 /joint_stop")
    exit()

# 啟動模擬
sim.startSimulation()
print('模擬已啟動')

# 主控制迴圈
def main():
    try:
        while True:
            # 控制第一隻滑動關節
            if keyboard.is_pressed('w'):  # 按下 'w' 鍵，第一隻滑動關節移動到 -0.15
                print("w 鍵被按下（控制第一隻滑動關節）")
                sim.setJointTargetPosition(slider1, -0.15)

            if keyboard.is_pressed('s'):  # 按下 's' 鍵，第一隻滑動關節回到初始位置
                print("s 鍵被按下（控制第一隻滑動關節）")
                sim.setJointTargetPosition(slider1, 0.0)

            # 控制第二隻滑動關節
            if keyboard.is_pressed('k'):  # 按下 'k' 鍵，第二隻滑動關節移動到 -0.15
                print("i 鍵被按下（控制第二隻滑動關節）")
                sim.setJointTargetPosition(slider2, -0.15)

            if keyboard.is_pressed('i'):  # 按下 'i' 鍵，第二隻滑動關節回到初始位置
                print("k 鍵被按下（控制第二隻滑動關節）")
                sim.setJointTargetPosition(slider2, 0.0)

            # 控制第三隻滑動關節
            if keyboard.is_pressed('o'):  # 按下 'o' 鍵，第三隻滑動關節移動到 0.0
                print("o 鍵被按下（控制第三隻滑動關節）")
                sim.setJointTargetPosition(slider3, 0.1)

            if keyboard.is_pressed('l'):  # 按下 'l' 鍵，第三隻滑動關節移動到 -0.15
                print("l 鍵被按下（控制第三隻滑動關節）")
                sim.setJointTargetPosition(slider3, -0.15)

            # 控制第四隻滑動關節
            if keyboard.is_pressed('e'):  # 按下 'e' 鍵，第四隻滑動關節移動到 -0.15
                print("u 鍵被按下（控制第四隻滑動關節）")
                sim.setJointTargetPosition(slider4, -0.15)

            if keyboard.is_pressed('d'):  # 按下 'd' 鍵，第四隻滑動關節回到初始位置
                print("j 鍵被按下（控制第四隻滑動關節）")
                sim.setJointTargetPosition(slider4, 0.0)

            # 停止模擬
            if keyboard.is_pressed('q'):  # 按下 'q' 鍵，停止模擬並退出
                print("q 鍵被按下 - 停止模擬")
                break

            # 降低 CPU 資源使用率
            time.sleep(0.05)

    except Exception as e:
        print(f"發生錯誤：{e}")

    finally:
        sim.stopSimulation()
        print("模擬已停止")

# 啟動主程式
main()
